<?php
// Configuración de CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json");

// Manejo de preflight (CORS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Credenciales de conexión
$server = "localhost";
$user = "root";
$pass = "";
$dbname = "chat";

// Crear conexión
$conn = new mysqli($server, $user, $pass, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a la base de datos"]);
    exit;
}

// Obtener datos del JSON
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->email) || !isset($data->pwd)) {
    http_response_code(400);
    echo json_encode(["error" => "Faltan datos"]);
    exit;
}

$email = $data->email;
$password = $data->pwd;

// Consulta preparada para evitar SQL Injection
$sql = "SELECT * FROM usuarios WHERE email = ? AND pwd = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

// Verificar si el usuario existe
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo json_encode(["success" => true, "user" => $user]);
} else {
    http_response_code(401);
    echo json_encode(["error" => "Credenciales incorrectas"]);
}

// Cerrar conexiones
$stmt->close();
$conn->close();
exit;
?>
