<?php
// Configuración de CORS
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: http://localhost:4200");  // Permitir solo el origen de Angular
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");  // Métodos permitidos
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");  // Encabezados permitidos

// Manejo de preflight (CORS)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header("HTTP/1.1 204 No Content"); // Sin cuerpo, solo los encabezados
    exit;
}

// Conexión a la base de datos
$servername = "localhost";
$username = "root";  // Ajusta según tu configuración
$password = "";      // Ajusta según tu configuración
$dbname = "chat";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a la base de datos: " . $conn->connect_error]);
    exit;
}

// Leer los datos JSON enviados desde Angular
$data = json_decode(file_get_contents("php://input"), true);

// Validar si los datos se recibieron correctamente
if (!$data) {
    http_response_code(400);
    echo json_encode(["error" => "Datos incorrectos o vacíos"]);
    exit;
}

// Extraer los datos del objeto 'usuario' enviado
$usuario = $data['usuario'] ?? '';            // Nombre de usuario
$mensaje = $data['mensaje'] ?? '';            // Mensaje
$activo = isset($data['activo']) ? (int)$data['activo'] : 1; // Si no se pasa, se asume 1 (activo)
$destinatario = $data['destinatario'] ; // Destinatario por defecto: 'todos'
$fecha = $data['fecha'] ; // Fecha actual si no se pasa

// Validar que los campos esenciales no estén vacíos
if (empty($usuario) || empty($mensaje)) {
    http_response_code(400);
    echo json_encode(["error" => "Usuario y mensaje son obligatorios"]);
    exit;
}

// Insertar mensaje en la base de datos con consulta preparada (prevención de SQL Injection)
$stmt = $conn->prepare("INSERT INTO chat (usuario, fecha, mensaje, activo, destinatario) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssds", $usuario, $fecha, $mensaje, $activo, $destinatario);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Mensaje enviado correctamente"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Error al enviar mensaje: " . $stmt->error]);
}

// Cerrar conexión
$stmt->close();
$conn->close();
?>