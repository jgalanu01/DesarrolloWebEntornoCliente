/* eslint-disable no-unused-vars */
import React from 'react'

function Cabecera() {
  return (
    <div className='app'>Cabecera</div>
  )
}

export default Cabecera