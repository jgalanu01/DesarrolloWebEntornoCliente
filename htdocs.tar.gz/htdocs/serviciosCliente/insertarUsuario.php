<?php
// Configuración de CORS
header("Access-Control-Allow-Origin: http://localhost:4200");  // Restringir a Angular en desarrollo
header("Content-Type: application/json; charset=UTF-8");    
header("Access-Control-Allow-Methods: POST, DELETE, OPTIONS");    
header("Access-Control-Max-Age: 3600");    
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

// Manejo de preflight (CORS)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header("HTTP/1.1 204 No Content");
    exit();
}

// Conexión a la base de datos
$servername = "localhost";
$username = "root";  // Ajusta según tu configuración
$password = "";      // Ajusta según tu configuración
$dbname = "chat";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a la base de datos: " . $conn->connect_error]);
    exit;
}

// Leer datos JSON enviados desde Angular
$data = json_decode(file_get_contents("php://input"), true);

$email = $data['email'] ?? '';
$nombre = $data['nombre'] ?? '';
$pwd = $data['pwd'] ?? '';
$activo = isset($data['activo']) ? (int)$data['activo'] : 1; // Por defecto, activo

// Validar datos
if (empty($email) || empty($nombre) || empty($pwd)) {
    http_response_code(400);
    echo json_encode(["error" => "Todos los campos son obligatorios"]);
    exit;
}


// Insertar usuario con consulta preparada (prevención de SQL Injection)
$stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, pwd, activo) VALUES (?, ?, ?, ?)");
$stmt->bind_param("sssi", $nombre, $email, $pwd, $activo);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Usuario insertado correctamente"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Error al insertar usuario: " . $stmt->error]);
}

// Cerrar conexión
$stmt->close();
$conn->close();
?>
