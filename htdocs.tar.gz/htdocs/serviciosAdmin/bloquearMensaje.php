<?php 
header('Access-Control-Allow-Origin: *'); 
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Manejo de preflight para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Datos de conexión a la base de datos
$host = "localhost"; // Cambia esto si es necesario
$user = "root"; // Usuario de la BD
$pass = ""; // Contraseña de la BD
$dbname = "chat"; // Nombre de la BD

// Conexión a la base de datos
$conexion = new mysqli($host, $user, $pass, $dbname);

// Verificar conexión
if ($conexion->connect_error) {
    http_response_code(500);
    echo json_encode(["resultado" => "ERROR", "mensaje" => "Error en la conexión a la BD"]);
    exit();
}

// Obtiene los datos de la solicitud
$json = file_get_contents('php://input');
$params = json_decode($json);

// Validación de datos
if (!isset($params->id)) {
    http_response_code(400);
    echo json_encode(["resultado" => "ERROR", "mensaje" => "Falta el id"]);
    exit();
}

// Actualizar el campo "activo" a 0 cuando el email coincide
$stmt = $conexion->prepare("UPDATE chat SET activo = 0 WHERE id = ? AND activo = 1");
$stmt->bind_param("i", $params->id);
$success = $stmt->execute();
$stmt->close();
$conexion->close();

$response = new stdClass();
if ($success && $stmt->affected_rows > 0) {
    $response->resultado = 'OK';
    $response->mensaje = 'Usuario desactivado correctamente';
} else {
    $response->resultado = 'ERROR';
    $response->mensaje = 'No se encontró un usuario activo con ese email';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
